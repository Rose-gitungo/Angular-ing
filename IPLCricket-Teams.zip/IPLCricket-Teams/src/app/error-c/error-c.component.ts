import { Component } from '@angular/core';

@Component({
  selector: 'app-error-c',
  templateUrl: './error-c.component.html',
  styleUrl: './error-c.component.css'
})
export class ErrorCComponent {

}
