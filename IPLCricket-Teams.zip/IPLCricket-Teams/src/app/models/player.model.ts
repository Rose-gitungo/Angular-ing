export interface Player {
    fullName: string;
    photo: string;
    team: string;
    price: string;
    playingStatus: string;
    role: string;
}