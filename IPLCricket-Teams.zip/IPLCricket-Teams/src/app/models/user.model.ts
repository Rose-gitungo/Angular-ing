// user.model.ts
export interface User {
    userName: string;
    email: string;
    password: string;
}
